package com.OneToManyMapping.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.OneToManyMapping.Employee;
import com.OneToManyMapping.services.EmployeeServices;

@RestController
@RequestMapping("/org")
public class EmployeeController {

	
	@Autowired
	EmployeeServices employeeServices;
	
	//add employee
	@PostMapping("/insert")
	public Employee addEmployee(@RequestBody Employee emp) 
	{
		return employeeServices.insertEmployee(emp);
		
	}
	
	//get all data 
	@GetMapping("/AllEmployee")
	public List<Employee> getAlldata()
	{
		return employeeServices.getAllEmployee();
	}
	
	
	//get employee by id
	@GetMapping("/employee/{id}")
	public Optional<Employee> getByid(@PathVariable Long id)
	{
		return employeeServices.getByIdEmployee(id);
	}
	
	//update employee
	@PutMapping("/update")
	public Employee updateEmployee(@RequestBody Employee emp)
	{
		return employeeServices.insertEmployee(emp);
	}
	
	//delete employee
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable Long id)
	{
		employeeServices.deleteEmployeeById(id);
		
		return "deleted";
	}
	
}
